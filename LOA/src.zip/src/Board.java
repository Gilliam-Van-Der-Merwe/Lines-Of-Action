
import javax.swing.JOptionPane;

  /*
 * This class implements the board. It stores an array that contains the content
 * of the board, and several functions that perform operations such as moving a
 * piece or counting the number of markers in a row, column, or diagonal.
 */
public class Board {

	// The size of the board
	private static int size;

	// The pieces
	public static final int INVALID = -1;
	public static final int EMPTY = 0;
	public static final int WHITE = 1;
	public static final int BLACK = 2;
	public static final int USER = BLACK;
	public static final int COMPUTER = WHITE;

	// The board
	private static int[][] board;
	private static String alphabet = "ABCDEFGHIJKLMNOP";
	// Convention: board[0][0] is the south west square

	/*
	 * Create and set up a new board
	 */
	public void newBoard(int newSize) {
     // Initialization of new board.
     board = new int[newSize][newSize];
	 size = newSize;
	 setSize(newSize);
		 for(int r = 0; r < newSize; r++)
		 {
			 for(int c = 0; c < newSize; c++)
			 {
				 board[r][c] = EMPTY;
			 }
		 }
		 for(int i = 1; i < newSize-1; i++)
		 {
			 	board[0][i] = BLACK;
		 }
		 for(int j = 1; j < newSize-1; j++)
		 {
			 board[newSize-1][j] = BLACK;
		 }
		 for(int k = 1; k < newSize-1; k++)
		 {
			 board[k][0] = WHITE;
		 }
		 for(int l = 1; l < newSize-1; l++)
		 {
			 board[l][newSize-1] = WHITE;
		 }
		 boardDisplay();  
	}
	
	public void backLayerBoardDisplay()
	{
		for(int r = 0; r < size; r++)
        {
          for(int c = 0; c < size; c++)
          {
            System.out.print(" " + getPiece(r, c));
          }
          System.out.println();
        }
	}
	
	public void boardDisplay()
	{
		// Display of Board.
		String temp, temp2;
	    System.out.print(" ");
	    for(int i = 0; i < size; i++)
		{
	    	 temp = alphabet.substring(i, i+1);
			 System.out.print(" " + temp + " ");
		}
		System.out.println();
		for(int r = 0; r < size; r++)
	    {
			temp2 = alphabet.substring(size-r-1, size-r);
			System.out.print(temp2);
			 for(int c = 0; c < size; c++)
			 {
				 if(board[r][c] == EMPTY)
			 	{
					System.out.print(" . ");
				}
				else if(board[r][c] == BLACK)
				{
					System.out.print(" B ");
				}
				else if(board[r][c] == WHITE)
				{
					System.out.print(" W ");
				}
			 }
			System.out.println();
	    }
	}
	/*
	 * Function that returns the piece currently on the board at the specified
	 * row and column.
	 */
	public static int getPiece(int row, int col) {
		if ((row < 0) || (row >= size)) {
			return INVALID;
		}
		if ((col < 0) || (col >= size)) {
			return INVALID;
		}
		return board[row][col];
	}

	/*
	 * Make a move. Check that the move is valid. If not, return false. If
	 * valid, modify the board that the piece has moved from (fromRow, fromCol)
	 * to (toRow, toCol).
	 */
	public void moveConversion(String movement, int pNum)
	{
		int[] moveConvert = new int[4];
		
		if(movement.equals("QUIT"))
        {
        	System.out.println("Player Quit");
        	System.exit(0);
        }
		
		for(int i = 0; i <= 3; i++)
		{
			for(int k = 0; k < alphabet.length(); k++)
			{
				if(movement.charAt(i) == alphabet.charAt(k))
				{
					if(i == 0 || i == 2)
					{
						moveConvert[i] = (size-1) - k;
					}
					else
					{
						moveConvert[i] = k;
					}					
				}
			}
		}
		if(isValidMove(pNum, moveConvert[0],moveConvert[1],moveConvert[2],moveConvert[3]))
		{
			makeMove(pNum, moveConvert[0],moveConvert[1],moveConvert[2],moveConvert[3]);
			boardDisplay();
		}
		else
		{
			System.out.println("ERROR: invalid move");
			String move = JOptionPane.showInputDialog("Enter Move");
			redoCheck(move, pNum);		
		}
	}
	
	public void redoCheck(String move, int pNum)
	{
		moveConversion(move, pNum);
	}
	
	public static boolean makeMove(int player, int fromRow, int fromCol, int toRow, int toCol)
	{
		boolean moved;
		if(getPiece(fromRow, fromCol) == getPiece(toRow, toCol))
		{
			moved = false;
		}
		else
		{
			board[toRow][toCol] = board[fromRow][fromCol];
			board[fromRow][fromCol] = 0;
			moved = true;
		}
		return moved;
	}

	/*
	 * Return the size of the board.
	 */
	public static int getSize() {
		System.out.println(size);
		return size;
	}
	
	public static void setSize(int temp)
	{
		size = temp;
	}
	/*
	 * Check if the given move is valid.  This entails checking that:
	 *
	 * - the player is valid
	 *
	 * - (fromRow, fromCol) is a valid coordinate
	 *
	 * - (toRow, toCol) is a valid coordinate
	 *
	 * - the from square contains a marker that belongs to the player
	 *
	 * - check that we are moving a "legal" number of squares
	 */
	public static boolean isValidMove(int player, int fromRow, int fromCol, int toRow, int toCol) 
	{
		boolean validity = true;
		int numSquaresMoved = 0, numSquaresAllowed = 0 ;
		
		if(getPiece(fromRow, fromCol) == 0)
		{
			validity = false;
		}
		else if(getPiece(fromRow, fromCol) == 1 && player == 2)
		{
			
		}
		else if(getPiece(fromRow, fromCol) == 2 && player == 1)
		{
			validity = false;
		}
		
		if(getPiece(fromRow, fromCol) == 2)
		{
			numSquaresMoved = SquareMoveCount(fromRow, fromCol, toRow, toCol);
		}
		else
		{
			numSquaresMoved = Player.moveC(fromRow, fromCol, toRow, toCol);
		}
		//numSquaresMoved = SquareMoveCount(fromRow, fromCol, toRow, toCol);
		numSquaresAllowed = ValidSquareMovementCount(fromRow, fromCol);
		//System.out.println("\nMoves: " + numSquaresMoved + " & ValidMoves: " + numSquaresAllowed + "\n");
		if(numSquaresAllowed == 0)
		{
			validity = false;
		}
		else if(numSquaresMoved > numSquaresAllowed)
		{
			validity = false;
		}
					
		return validity;
	}
	public static int ValidSquareMovementCount(int fromRow, int fromCol) 
	{
		int validMoveCount = 0;
		validMoveCount = rowCount(fromRow);
		//System.out.println("RowCount: " + validMoveCount);
		validMoveCount = colCount(fromCol);
		//System.out.println("ColCount: " + validMoveCount);
		validMoveCount =  diagNortheastCount(fromRow, fromCol);
		//System.out.println("NECount: " + validMoveCount);
		validMoveCount =  diagNorthwestCount(fromRow, fromCol);
		//System.out.println("NWCount: " + validMoveCount + "\n");
		return validMoveCount;
	}

	public static int SquareMoveCount(int fromRow, int fromCol, int toRow, int toCol)
	{
		int moveCount = 0, posR = fromRow, posC = fromCol;
		if(posR > toRow && posC < toCol)
		{
			while(posR > toRow && posC < toCol)
			{
				posR--;
				posC++;
				moveCount++;
			}
		}
		else if(posR < toRow && posC > toCol)
		{
			while(posR < toRow && posC > toCol)
			{
				posR++;
				posC--;
				moveCount++;
			}
		}
		else if(posR > toRow && posC > toCol)
		{
			while(posR > toRow && posC > toCol)
			{
				posR--;
				posC--;
				moveCount++;
			}
		}
		return moveCount;
	}

	/*
	 * Count the number of markers (non-empty squares) in the specified row.
	 */
	public static int rowCount(int row) 
	{
		int temp = 0;
		
		for(int r = 0 ; r < size; r++)
        {
          for(int c = 1; c < size; c++)
          {
        	  if(board[r][c] != 0 && r == row)
        	  {
        		  if(r != 0 && r!= size)
        		  {
        			  temp++;  
        		  }
        	  }
          }
        }
		return temp;
	}

	/*
	 * Count the number of markers (non-empty squares) in the specified column.
	 */
	public static int colCount(int col)
	{
		int temp = 0;
		for(int r = 0; r < size; r++)
        {
          for(int c = 0; c < size; c++)
          {
        	  if(board[r][c] != 0 && c == col && r != 0 && c != 0)
        	  {
        		  temp++;
        	  }
          }
        }
		return temp;
	}

	/*
	 * Count the number of markers (non-empty squares) in the diagonal that runs
	 * from the north-east corner to the south-west corner of the board, and
	 * that passes through the specified row and column.
	 */
	public static int diagNortheastCount(int row, int col) {
		int temp = 0, posR = row, posC = col;
		
		if(posR < size && posC >= 0)
		{
			while(posR < size && posC >= 0)
			{
				  if(board[posR][posC] != 0 && posR != row && posC != col)
				  {
					  temp++;
				  }
				  posR++;
				  posC--;
			}
		}
		else if(posR > 0 && posC < size)
		{
			while(posR > 0 && posC < size)
			{
				  if(board[posR][posC] != 0 && posR != row && posC != col)
				  {
					  temp++;
				  }
				  posR--;
				  posC++;
			}
		}		
		return temp;
	}

	/*
	 * Count the number of markers (non-empty squares) in the diagonal that runs
	 * from the north-west corner to the south-east corner of the board, and
	 * that passes through the specified row and column.
	 */
	public static int diagNorthwestCount(int row, int col) {
		int temp = 0, posR = row, posC = col;
		if(posR >= 0 && posC >= 0)
		{
			while(posR >= 0 && posC >= 0)
			{
				  if(board[posR][posC] != 0 && posR != row && posC != col)
				  {
					  temp++;
				  }
				  posR--;
				  posC--;
			}
		}
		else if(posR <  size && posC < size)
		{
			while(posR < size && posC < size)
			{
				  if(board[posR][posC] != 0 && posR != row && posC != col)
				  {
					  temp++;
				  }
				  posR++;
				  posC++;
			}
		}
		return temp;
	}

	public static boolean hasWon(int player) {
		return Util.isConnected(board, player);
	}

}
