
import javax.swing.JOptionPane;


public class TestLOA
{		
	  public static void main(String[]  args)
	  {
	    Board test = new Board();
	    Player compTurn = new Player();
	    int size = Integer.parseInt(args[0]);
	    
	    int mode, computerPlayer = 1, userPlayer = 2, currentPlayer = 1;
	    String playerMove;
	    
	    if(args.length < 2)
	    {
	    	System.out.println("ERROR: too few arguments");
	    	System.exit(0);
	    }
	    
	    if(size < 4 || size > 16)
	    {
	    	System.out.println("ERROR: illegal size");
	    	System.exit(0);
	    }
	    else
	    {
	    	mode = Integer.parseInt(args[1]);
	        if(mode < 0 || mode > 2)
	        {
	        	System.out.println("ERROR: illegal mode");
	        	System.exit(0);
	        }
	        else
	        {
	        	if(mode == 0)
	        	{
	                test.newBoard(size);
	                playerMove = args[2];
	                
	                if(playerMove.equals("QUIT"))
	                {
	                	System.out.println("Player Quit");
	                	System.exit(0);
	                }
	                else if(playerMove.length() > 4 || playerMove.length() < 4)
	                {
	                	System.out.println("ERROR: invalid move");
	                	System.exit(0);
	                }
	                else
	                {
	                	System.out.println("\n" + playerMove + "\n");
	                	test.moveConversion(playerMove, userPlayer);
	                	
	                	if(Board.hasWon(userPlayer))
	                	{
	                		System.out.println("WINNER: " + userPlayer);
	                	}
	                	else
	                	{
	                		System.out.println("\n" + "DRAW");
	                	}
	                }
	        	}
	        	else if( mode == 1)
	        	{
	        		boolean checkOne = false;	        		       		
	        		test.newBoard(size);
	        		playerMove = "Default";
	        		
	        		while(Board.hasWon(currentPlayer) == false)
	        		{
	        			while(checkOne == false)
	                    {
	        				currentPlayer = userPlayer;
	        				playerMove = JOptionPane.showInputDialog("Enter Move");
	        				
	                    	if(playerMove.equals("QUIT"))
	                        {
	                        	System.out.println("Player Quit");
	                        	System.exit(0);
	                        }
	                    	else if(playerMove.length() > 4 || playerMove.length() < 4)
	                        {
	                        	System.out.println("ERROR: invalid move");
	                        }
	                    	else
	                    	{
	                    		checkOne = true;
	                    	}
	                    }
	                    System.out.println("\n" + playerMove + "\n");
	                	test.moveConversion(playerMove, currentPlayer);
	                	
	                	currentPlayer = computerPlayer;
	                	compTurn.checkIfValid(size);
	                	
	                	playerMove = JOptionPane.showInputDialog("Enter Move");
	        		}
	            	
	            	if(Board.hasWon(currentPlayer))
	            	{
	            		System.out.println("\nWINNER: " + currentPlayer);
	            	}
	            	else
	            	{
	            		System.out.println("\nDRAW");
	            	}            
	        	}
	        	else if(mode == 2)
	        	{
	        		
	        	}
	        }
	    }
	  }
	}
