
public class Player
{
	private static Board utility = new Board();
	private static int limitSize;
	
	public static int randomComputerRow()
	{
		int rCR = (int) (Math.random() * limitSize) + 0;
		return rCR;
	}
	
	public static int randomComputerCol()
	{
		int rCC = (int) (Math.random() * limitSize) + 0;
		return rCC;
	}
	
	public void checkIfValid(int boardSize)
	{
		boolean valid = false;
		limitSize = boardSize;
		int fromRow, fromCol, toRow, toCol;
		
		while(valid == false)
		{
			fromRow = (int) randomComputerRow();
			//System.out.println(fromRow);
			fromCol = randomComputerCol();
			//System.out.println(fromCol);
			toRow = randomComputerRow();
			//System.out.println(toRow);
			toCol = randomComputerCol();
			//System.out.println(toCol);
			
			if(Board.getPiece(fromRow, fromCol) == 1)
			{
				//moveC(fromRow, fromCol, toRow, toCol);
				valid = Board.isValidMove(1, fromRow, fromCol, toRow, toCol);
				if(valid == true)
				{
					Board.makeMove(1, fromRow, fromCol, toRow, toCol);
					Board.ValidSquareMovementCount(fromRow, fromCol);
					utility.boardDisplay();
				}
			}		
		}
	}
	
	public static int moveC(int fromRow, int fromCol, int toRow, int toCol )
	{
		return Board.SquareMoveCount(fromRow, fromCol, toRow, toCol);
	}
	/*
	public static void main(String[]	args)
	{
		int r = 0, c = 0;
		limitSize = TestLOA.getSize();
		for(int i = 0; i < 10; i++)
		{
			r = randomComputerRow();
			c = randomComputerCol();
			System.out.println(r + " & " + c);
		}				
	}
	*/
}
